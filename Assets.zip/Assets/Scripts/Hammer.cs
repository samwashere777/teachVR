﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hammer : MonoBehaviour
{
    /*
    public TextMesh scoreText;
    private int score = 0; // holds the score

    void Start()
    {
        scoreText.text = "Score: " + score;
    }

    void Update()
    {
        scoreText.text = "Score: " + score;
    }

    void OnTriggerEnter(Collider other)
    {
        score += 1;
    }*/
/*
    // Start is called before the first frame update
    void Start()
    {
        // Check if controller is conntected
        if (OVRInput.IsControllerConnected(OVRInput.Controller.LTrackedRemote || OVRInput.IsControllerConnected(OVRInput.Controller.RTrackedRemote))) {
            scoreText.text = "SCORE: " + score;
        }
        else
        {
            scoreText.text = "Connect Controller...";
        }
        
    }


    // Update is called once per frame
    void Update()
    {
        // Hit Variable
        RaycastHit hitGameObject;

        // check if hit mole. store what hit

        if (Physics.Raycast(transform.position, -transform.up, out hitGameObject))
        {
            // Check hit a mole
            if (hitGameObject.transform.GetComponent<Mole>() != null)
            {
                // Get Mole
                Mole moleIHit = hitGameObject.transform.GetComponent<Mole>();

                // Hide Mole
                moleIHit.HideMole();

                // Update Score
                score++;
                scoreText.text = "SCORE: " + score;
            }
        }
        
    }
*/
}