﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonPress : MonoBehaviour
{
    // Show and Hide Variables
    public float VisibleYHeight = -.3f;
    public float HiddenYHeight = .46f;
    private Vector3 myNewXYZPosition; // position to move Mole
    public float speed = 2f;          // speed the moles move
    public float hideMoleTimer = .2f;


    // Start is called before the first frame update
    void Start()
    {
        HideMole();
    }

    // Update is called once per frame
    void Update()
    {
        // Move mole to new position
        transform.localPosition = Vector3.Lerp(
            transform.localPosition, 
            myNewXYZPosition,
            Time.deltaTime * speed);

        // Hide Mole if timer less than 0
        hideMoleTimer -= Time.deltaTime;
        if (hideMoleTimer < 0)
        {
            HideMole();
        }
    }

    // hide the mole
    public void HideMole()
    {
        // Set current position to hidden
        myNewXYZPosition = new Vector3(
               transform.localPosition.x, 
               HiddenYHeight,
               transform.localPosition.z
        );
    }

    // show the mole
    public void ShowMole()
    {
        // Set current position to visible
        myNewXYZPosition = new Vector3(
               transform.localPosition.x,
               VisibleYHeight,
               transform.localPosition.z
        );

        // Reset the hideMoleTimer to 1.5 seconds before hiding
        hideMoleTimer = .2f;
    }

    void OnTriggerEnter(Collider other)
    {
        //gameManager.Disappear();
        ShowMole();
        //changeScore.moleHit = true;
        //changeScore.score += 20;
    }
}
