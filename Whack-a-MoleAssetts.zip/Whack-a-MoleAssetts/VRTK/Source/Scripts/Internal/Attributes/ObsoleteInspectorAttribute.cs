﻿namespace VRTK
{
    using UnityEngine;
    public class ObsoleteInspectorAttribute : PropertyAttribute
    {
    }
}